from __future__ import annotations

import re
import unicodedata
from datetime import date

from app.calendar_catalog import CalendarCatalog, normalize
from app.config import WEEKDAY_NAMES
from app.models import ScheduleProposal
from app.schedule_engine import (
    NATIONAL_HOLIDAYS_2026,
    business_day_from_month_end,
    business_day_from_month_start,
    business_days,
    dates_for_definition,
    every_day,
    month_days,
    nth_weekday_of_month,
    shift_dates,
    weekdays,
)


DAY_WORDS = {
    "LUNES": 0,
    "MARTES": 1,
    "MIERCOLES": 2,
    "JUEVES": 3,
    "VIERNES": 4,
    "SABADO": 5,
    "SABADOS": 5,
    "DOMINGO": 6,
    "DOMINGOS": 6,
}


def _norm(value: str) -> str:
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", value.upper()).strip()


def _national_holidays(year: int) -> set[date]:
    return NATIONAL_HOLIDAYS_2026 if year == 2026 else set()


def _decorate(proposal: ScheduleProposal, catalog: CalendarCatalog) -> ScheduleProposal:
    proposal.matches = catalog.search(proposal.query)
    if proposal.reusable_calendar:
        return proposal
    if proposal.selected_dates:
        exact_names: list[str] = []
        for name, definition in catalog.definitions.items():
            values, warnings = dates_for_definition(definition, proposal.year)
            if not warnings and values == proposal.selected_dates and catalog.find_exact(name):
                exact_names.append(name)
        if exact_names:
            proposal.reusable_calendar = exact_names[0]
            proposal.reuse_status = "Coincidencia exacta por fechas y regla conocida"
            proposal.matches.sort(
                key=lambda match: (
                    normalize(match.record.name).replace(" ", "")
                    != normalize(proposal.reusable_calendar).replace(" ", ""),
                    -match.score,
                )
            )
        else:
            proposal.reuse_status = "No hay coincidencia exacta confirmable con las definiciones disponibles"
    return proposal


def _from_known_calendar(query: str, year: int, calendar_name: str, catalog: CalendarCatalog, offset: int = 0) -> ScheduleProposal:
    definition = catalog.definition(calendar_name)
    matches = catalog.find_exact(calendar_name)
    if definition:
        dates, warnings = dates_for_definition(definition, year)
        if offset:
            dates = shift_dates(dates, offset, year)
        proposal = ScheduleProposal(
            query=query,
            year=year,
            title=f"Calendario {calendar_name}",
            schedule_type="Based on Calendar",
            selected_dates=dates,
            regular_calendar=calendar_name,
            based_on_mode="Calendar Days",
            calendar_rule="Order only on calendar days",
            offset_days=offset,
            confidence=str(definition.get("confidence", "Alta")),
            explanation=str(definition.get("description", "Calendario existente con regla conocida.")),
            warnings=warnings,
            reusable_calendar=calendar_name,
            reuse_status="Calendario existente seleccionado; regla interna conocida",
        )
        if offset:
            proposal.warnings.append("El desplazamiento se simula sobre las fechas del calendario; valide en Control-M si debe implementarse como regla relativa, calendario derivado o confirmación/shift.")
    else:
        proposal = ScheduleProposal(
            query=query,
            year=year,
            title=f"Calendario {calendar_name}",
            schedule_type="Based on Calendar",
            regular_calendar=calendar_name,
            based_on_mode="Calendar Days",
            calendar_rule="Order only on calendar days",
            offset_days=offset,
            confidence="Baja",
            explanation="El calendario figura en el catálogo, pero el Excel no contiene sus fechas ni su regla interna.",
            warnings=["Importe una definición JSON o un export con fechas para obtener una vista anual exacta."],
            reusable_calendar=calendar_name,
            reuse_status="Existe en el catálogo, pero su regla interna no está disponible",
        )
    if len(matches) > 1:
        proposal.warnings.append(f"Hay {len(matches)} registros con el nombre {calendar_name}; revise tipo y servidor.")
    return _decorate(proposal, catalog)


def interpret(query: str, year: int, catalog: CalendarCatalog) -> ScheduleProposal:
    text = _norm(query)
    mentioned = catalog.names_mentioned(query)
    offset = 0
    before = re.search(r"(?:UN|1)\s+DIA\s+ANTES", text)
    after = re.search(r"(?:UN|1)\s+DIA\s+DESPUES", text)
    generic_offset = re.search(r"(\d+)\s+DIAS?\s+(ANTES|DESPUES)", text)
    if before:
        offset = -1
    elif after:
        offset = 1
    elif generic_offset:
        offset = int(generic_offset.group(1)) * (-1 if generic_offset.group(2) == "ANTES" else 1)
    # Cuando LABORABL forma parte de una regla ordinal (L1/L2/D1), el nombre
    # identifica el calendario base pero no constituye toda la planificación.
    relative_labour_rule = (
        mentioned
        and normalize(mentioned[0]).replace(" ", "") == "LABORABL"
        and any(word in text for word in ("PENULTIMO", "ULTIMO", "PRIMER"))
    )
    biweekly_sunday_rule = (
        mentioned
        and normalize(mentioned[0]).replace(" ", "") == "DOMINGOS"
        and ("CADA DOS SEMANAS" in text or "CADA 2 SEMANAS" in text or "DOS DOMINGOS" in text)
    )
    if mentioned and not relative_labour_rule and not biweekly_sunday_rule:
        return _from_known_calendar(query, year, mentioned[0], catalog, offset)

    # Días laborables relativos al inicio o final del mes.
    if "LABORABL" in text and any(word in text for word in ("PENULTIMO", "ULTIMO", "PRIMER")):
        holidays = _national_holidays(year)
        if "PENULTIMO" in text:
            dates = business_day_from_month_end(year, 2, holidays)
            token = "L2"
            title = "Penúltimo día laborable de cada mes"
        elif "ULTIMO" in text:
            dates = business_day_from_month_end(year, 1, holidays)
            token = "L1"
            title = "Último día laborable de cada mes"
        else:
            dates = business_day_from_month_start(year, 1, holidays)
            token = "D1"
            title = "Primer día laborable de cada mes"
        proposal = ScheduleProposal(
            query=query, year=year, title=title, schedule_type="Based on Calendar",
            selected_dates=dates, days_of_month=[token], regular_calendar="LABORABL",
            based_on_mode="Month Days (Dependent on Calendar)",
            calendar_rule=f"Order on {token} working day of each month",
            confidence="Alta" if year == 2026 else "Media",
            explanation="Se toma el ordinal sobre los días existentes en el calendario LABORABL.",
        )
        if year != 2026:
            proposal.warnings.append("Los festivos exactos solo están cargados para 2026; revise el calendario LABORABL del año seleccionado.")
        return _decorate(proposal, catalog)

    # Calendario laborable o ejecución diaria sin fines de semana/festivos.
    if "LABORABL" in text or "SIN FESTIVOS" in text or "SIN FINES DE SEMANA" in text or "LUNES A VIERNES" in text:
        holidays = _national_holidays(year)
        use_holidays = "FESTIV" in text or "LABORABL" in text
        dates = business_days(year, holidays if use_holidays else set())
        proposal = ScheduleProposal(
            query=query, year=year,
            title="Días laborables" if use_holidays else "Lunes a viernes",
            schedule_type="Based on Calendar" if use_holidays else "Week Days",
            selected_dates=dates,
            days_of_week=WEEKDAY_NAMES[:5],
            regular_calendar="LABORABL" if use_holidays else "",
            based_on_mode="Calendar Days" if use_holidays else "",
            calendar_rule="Order only on calendar days" if use_holidays else "",
            confidence="Alta" if year == 2026 or not use_holidays else "Media",
            explanation="Ejecución de lunes a viernes" + (" excluyendo las fechas de FESTIVOSNAC." if use_holidays else "."),
        )
        if use_holidays and year != 2026:
            proposal.warnings.append("Los festivos exactos solo están cargados para 2026.")
        return _decorate(proposal, catalog)

    # Tercer/primer/último día de semana de cada mes.
    ordinal_map = {"PRIMER": 1, "SEGUNDO": 2, "TERCER": 3, "CUARTO": 4, "ULTIMO": -1}
    selected_day = next((index for word, index in DAY_WORDS.items() if re.search(rf"\b{word}\b", text)), None)
    ordinal = next((value for word, value in ordinal_map.items() if re.search(rf"\b{word}\b", text)), None)
    if selected_day is not None and ordinal is not None:
        dates = nth_weekday_of_month(year, selected_day, ordinal)
        ordinal_name = next(word.title() for word, value in ordinal_map.items() if value == ordinal)
        title = f"{ordinal_name} {WEEKDAY_NAMES[selected_day].lower()} de cada mes"
        token = f"{'L' if ordinal < 0 else 'D'}{abs(ordinal)}W"
        proposal = ScheduleProposal(
            query=query, year=year, title=title, schedule_type="Advanced Scheduling",
            selected_dates=dates, days_of_week=[WEEKDAY_NAMES[selected_day]],
            calendar_rule=token, confidence="Alta",
            explanation="Se selecciona el día de la semana dentro de la semana ordinal del mes.",
        )
        return _decorate(proposal, catalog)

    # Dos domingos al mes cada dos semanas: primera y tercera semana.
    if "DOMING" in text and ("CADA DOS SEMANAS" in text or "CADA 2 SEMANAS" in text or "DOS DOMINGOS" in text):
        dates = nth_weekday_of_month(year, 6, 1) | nth_weekday_of_month(year, 6, 3)
        proposal = ScheduleProposal(
            query=query, year=year, title="Primer y tercer domingo de cada mes",
            schedule_type="Advanced Scheduling", selected_dates=dates,
            days_of_week=["Domingo"], calendar_rule="W1/Domingo + W3/Domingo",
            confidence="Media",
            explanation="Se interpreta como dos domingos separados por dos semanas.",
            assumptions=["Se usan el primer y el tercer domingo de cada mes; confirme el anclaje deseado."],
        )
        return _decorate(proposal, catalog)

    # Cada N meses en uno o varios días de mes.
    every_n_months = re.search(r"CADA\s+(\d+)\s+MESES?", text)
    day_numbers = {int(value) for value in re.findall(r"\b(?:DIA|DIAS|LOS DIAS)\s+(\d{1,2})\b", text)}
    if every_n_months and day_numbers:
        step = max(1, int(every_n_months.group(1)))
        months = set(range(1, 13, step))
        dates = month_days(year, day_numbers, months)
        proposal = ScheduleProposal(
            query=query, year=year, title=f"Cada {step} meses, día(s) {', '.join(map(str, sorted(day_numbers)))}",
            schedule_type="Month Days", selected_dates=dates,
            days_of_month=[str(value) for value in sorted(day_numbers)], months=sorted(months),
            confidence="Media", explanation="Planificación por días de mes y meses seleccionados.",
            assumptions=["La secuencia comienza en enero; cambie el mes de inicio si el ciclo real usa otro anclaje."],
        )
        return _decorate(proposal, catalog)

    # Todos los días de una o varias semanas.
    selected_weekdays = {index for word, index in DAY_WORDS.items() if re.search(rf"\b{word}\b", text)}
    if selected_weekdays and not ("PENULTIMO" in text or "ULTIMO DIA" in text):
        dates = weekdays(year, selected_weekdays)
        names = [WEEKDAY_NAMES[index] for index in sorted(selected_weekdays)]
        proposal = ScheduleProposal(
            query=query, year=year, title="Todos los " + ", ".join(name.lower() for name in names),
            schedule_type="Week Days", selected_dates=dates, days_of_week=names,
            confidence="Alta", explanation="Planificación directa por día de la semana; no necesita un calendario regular.",
        )
        return _decorate(proposal, catalog)

    # Penúltimo/último día natural del mes, opcionalmente evitando fin de semana.
    if "PENULTIMO" in text or "ULTIMO DIA" in text:
        avoid_weekend = "SABADO" in text or "DOMINGO" in text or "FIN DE SEMANA" in text
        ordinal = 2 if "PENULTIMO" in text else 1
        if avoid_weekend:
            dates = business_day_from_month_end(year, ordinal)
            schedule_type = "Based on Calendar"
            regular = "WEEKDAYS"
            based_on = "Month Days (Dependent on Calendar)"
        else:
            dates = set()
            for month in range(1, 13):
                import calendar
                last = calendar.monthrange(year, month)[1]
                dates.add(date(year, month, last - ordinal + 1))
            schedule_type = "Month Days"
            regular = ""
            based_on = ""
        proposal = ScheduleProposal(
            query=query, year=year,
            title=("Penúltimo" if ordinal == 2 else "Último") + " día del mes" + (" laborable" if avoid_weekend else ""),
            schedule_type=schedule_type, selected_dates=dates,
            days_of_month=[f"L{ordinal}"], regular_calendar=regular, based_on_mode=based_on,
            calendar_rule=f"L{ordinal}", confidence="Alta",
            explanation="Selección relativa desde el final de cada mes.",
        )
        return _decorate(proposal, catalog)

    if any(term in text for term in ("TODOS LOS DIAS", "CADA DIA", "DIARIA", "DIARIO")):
        proposal = ScheduleProposal(
            query=query, year=year, title="Todos los días", schedule_type="Every Day",
            selected_dates=every_day(year), confidence="Alta",
            explanation="Ejecución diaria durante todos los meses.",
        )
        return _decorate(proposal, catalog)

    # Sin regla interpretable: se devuelve el catálogo sugerido, nunca fechas inventadas.
    proposal = ScheduleProposal(
        query=query, year=year, title="Revisión manual necesaria", schedule_type="No determinado",
        confidence="Baja", explanation="No se ha identificado una regla suficiente para calcular fechas.",
        warnings=["Seleccione una coincidencia del catálogo o reformule indicando día, frecuencia y calendario base."],
    )
    return _decorate(proposal, catalog)
