from __future__ import annotations

import calendar
import tkinter as tk
from datetime import date
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from app.calendar_catalog import CalendarCatalog
from app.config import (
    APP_TITLE,
    CATALOG_PATH,
    COLORS,
    DEFINITIONS_PATH,
    MONTH_NAMES,
    WEEKDAY_LABELS,
)
from app.interpreter import interpret
from app.models import ScheduleProposal


EXAMPLES = [
    "Todos los lunes del mes",
    "Días laborables según calendario LABORABL",
    "Un día antes de los días de cierre según CALCIERR",
    "Penúltimo día del mes que no sea sábado ni domingo",
    "Ejecución diaria sin fines de semana",
    "Ejecución diaria sin festivos basada en LABORABL",
    "Cada 3 meses los días 15",
    "Dos domingos al mes cada dos semanas",
    "Penúltimo día laborable de cada mes",
    "Tercer lunes de cada mes",
]


class YearCalendarView(tk.Frame):
    def __init__(self, master, year: int, on_year_change, **kwargs):
        super().__init__(master, bg=COLORS["panel"], **kwargs)
        self.year = year
        self.selected_dates: set[date] = set()
        self.on_year_change = on_year_change
        self._build_header()
        self.months_frame = tk.Frame(self, bg=COLORS["panel"])
        self.months_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        for col in range(4):
            self.months_frame.grid_columnconfigure(col, weight=1, uniform="month")
        for row in range(3):
            self.months_frame.grid_rowconfigure(row, weight=1, uniform="monthrow")
        self.render()

    def _build_header(self):
        header = tk.Frame(self, bg="#D7E1F3", height=42)
        header.pack(fill="x", padx=8, pady=8)
        header.pack_propagate(False)
        tk.Button(
            header, text="‹", command=lambda: self._change_year(-1),
            bg="#D7E1F3", fg=COLORS["navy"], relief="flat", font=("Segoe UI", 20, "bold"),
            activebackground=COLORS["blue_light"], cursor="hand2",
        ).pack(side="left", padx=(14, 4))
        self.year_label = tk.Label(
            header, text=str(self.year), bg="#D7E1F3", fg=COLORS["text"],
            font=("Segoe UI", 11, "bold"), padx=18,
        )
        self.year_label.pack(side="left")
        tk.Button(
            header, text="›", command=lambda: self._change_year(1),
            bg="#D7E1F3", fg=COLORS["navy"], relief="flat", font=("Segoe UI", 20, "bold"),
            activebackground=COLORS["blue_light"], cursor="hand2",
        ).pack(side="left", padx=4)
        self.count_label = tk.Label(
            header, text="0 fechas", bg="#D7E1F3", fg=COLORS["muted"],
            font=("Segoe UI", 10),
        )
        self.count_label.pack(side="right", padx=16)

    def _change_year(self, delta: int):
        self.on_year_change(self.year + delta)

    def set_data(self, year: int, selected_dates: set[date]):
        self.year = year
        self.selected_dates = selected_dates
        self.year_label.configure(text=str(year))
        self.count_label.configure(text=f"{len(selected_dates)} fechas")
        self.render()

    def render(self):
        for child in self.months_frame.winfo_children():
            child.destroy()
        cal = calendar.Calendar(firstweekday=0)
        for month in range(1, 13):
            row, col = divmod(month - 1, 4)
            card = tk.Frame(
                self.months_frame, bg=COLORS["surface"],
                highlightbackground=COLORS["line"], highlightthickness=1,
            )
            card.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
            for day_col in range(7):
                card.grid_columnconfigure(day_col, weight=1, uniform=f"d{month}")
            title = tk.Label(
                card, text=f"{MONTH_NAMES[month - 1]} {self.year}",
                bg=COLORS["blue"], fg="white", font=("Segoe UI", 9, "bold"), pady=3,
            )
            title.grid(row=0, column=0, columnspan=7, sticky="ew")
            for day_col, label in enumerate(WEEKDAY_LABELS):
                tk.Label(
                    card, text=label, bg="#F7F9FB", fg=COLORS["text"],
                    font=("Segoe UI", 8, "bold"), pady=2,
                ).grid(row=1, column=day_col, sticky="nsew")
            weeks = cal.monthdayscalendar(self.year, month)
            while len(weeks) < 6:
                weeks.append([0] * 7)
            for week_row, week in enumerate(weeks, start=2):
                for day_col, day_number in enumerate(week):
                    if not day_number:
                        text, bg, fg = "", COLORS["surface"], COLORS["muted"]
                    else:
                        current = date(self.year, month, day_number)
                        selected = current in self.selected_dates
                        text = str(day_number)
                        bg = COLORS["selected"] if selected else COLORS["surface"]
                        fg = "#5B3400" if selected else ("#8B969E" if day_col >= 5 else COLORS["text"])
                    tk.Label(
                        card, text=text, bg=bg, fg=fg, font=("Segoe UI", 8),
                        padx=2, pady=1, anchor="center",
                    ).grid(row=week_row, column=day_col, sticky="nsew", padx=1, pady=1)


class ControlMCalendarApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1540x900")
        self.root.minsize(1280, 760)
        self.root.configure(bg=COLORS["panel"])
        self.catalog = CalendarCatalog.from_json(CATALOG_PATH, DEFINITIONS_PATH)
        self.year = 2026
        self.proposal: ScheduleProposal | None = None
        self._configure_styles()
        self._build_shell()
        self._load_catalog_tree()
        self.query_text.insert("1.0", EXAMPLES[0])
        self.analyze()

    def _configure_styles(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", font=("Segoe UI", 9), background=COLORS["panel"], foreground=COLORS["text"])
        style.configure("TFrame", background=COLORS["panel"])
        style.configure("TLabel", background=COLORS["panel"], foreground=COLORS["text"])
        style.configure("TLabelframe", background=COLORS["panel"], bordercolor=COLORS["line"])
        style.configure("TLabelframe.Label", background=COLORS["panel"], foreground=COLORS["navy"], font=("Segoe UI", 9, "bold"))
        style.configure("TButton", background="#E7EEF4", foreground=COLORS["text"], padding=(9, 6), bordercolor=COLORS["line"])
        style.map("TButton", background=[("active", COLORS["blue_light"]), ("pressed", "#C9DDEA")])
        style.configure("Accent.TButton", background=COLORS["navy"], foreground="white", padding=(12, 7), font=("Segoe UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", COLORS["navy_dark"]), ("pressed", COLORS["navy_dark"])])
        style.configure("Treeview", background="white", fieldbackground="white", foreground=COLORS["text"], rowheight=25, bordercolor=COLORS["line"])
        style.configure("Treeview.Heading", background=COLORS["blue_light"], foreground=COLORS["navy_dark"], font=("Segoe UI", 9, "bold"))
        style.map("Treeview", background=[("selected", COLORS["navy"])], foreground=[("selected", "white")])
        style.configure("TNotebook", background=COLORS["panel"], bordercolor=COLORS["line"])
        style.configure("TNotebook.Tab", background="#DCE6ED", foreground=COLORS["text"], padding=(12, 6))
        style.map("TNotebook.Tab", background=[("selected", COLORS["selected"])], foreground=[("selected", "#4D2C00")])

    def _build_shell(self):
        self._build_topbar()
        body = ttk.Panedwindow(self.root, orient="horizontal")
        body.pack(fill="both", expand=True, padx=8, pady=(0, 6))

        left = ttk.Frame(body, width=300)
        center = ttk.Frame(body)
        right = ttk.Frame(body, width=405)
        body.add(left, weight=0)
        body.add(center, weight=1)
        body.add(right, weight=0)

        self._build_left(left)
        self.calendar_view = YearCalendarView(center, self.year, self._set_year)
        self.calendar_view.pack(fill="both", expand=True)
        self._build_right(right)

        self.status = tk.StringVar(value="Catálogo cargado")
        tk.Label(
            self.root, textvariable=self.status, anchor="w", bg=COLORS["navy_dark"], fg="white",
            font=("Segoe UI", 9), padx=12, pady=4,
        ).pack(fill="x")

    def _build_topbar(self):
        bar = tk.Frame(self.root, bg=COLORS["navy"], height=52)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        tk.Label(
            bar, text="Control-M", bg=COLORS["navy"], fg="white",
            font=("Segoe UI", 16, "bold"), padx=16,
        ).pack(side="left", fill="y")
        tk.Label(
            bar, text="Calendar Assistant  |  búsqueda y simulación de Scheduling",
            bg=COLORS["navy"], fg="#DCEFFF", font=("Segoe UI", 10),
        ).pack(side="left", fill="y")
        tk.Label(
            bar, text="v1", bg=COLORS["navy_dark"], fg="white",
            font=("Segoe UI", 9, "bold"), padx=14,
        ).pack(side="right", fill="y")

    def _build_left(self, parent):
        query_box = ttk.LabelFrame(parent, text="Petición del usuario")
        query_box.pack(fill="x", padx=(0, 6), pady=(8, 5))
        self.query_text = tk.Text(
            query_box, height=4, wrap="word", bg="white", fg=COLORS["text"],
            insertbackground=COLORS["text"], relief="solid", borderwidth=1,
            highlightthickness=0, font=("Segoe UI", 10), padx=8, pady=7,
        )
        self.query_text.pack(fill="x", padx=8, pady=(8, 5))
        self.query_text.bind("<Control-Return>", lambda _event: self.analyze())
        ttk.Button(query_box, text="Analizar y mostrar", style="Accent.TButton", command=self.analyze).pack(fill="x", padx=8, pady=(0, 8))

        examples_box = ttk.LabelFrame(parent, text="Ejemplos")
        examples_box.pack(fill="x", padx=(0, 6), pady=5)
        self.examples = ttk.Combobox(examples_box, state="readonly", values=EXAMPLES)
        self.examples.pack(fill="x", padx=8, pady=8)
        self.examples.bind("<<ComboboxSelected>>", self._use_example)

        catalog_box = ttk.LabelFrame(parent, text="Calendarios existentes")
        catalog_box.pack(fill="both", expand=True, padx=(0, 6), pady=5)
        action_row = ttk.Frame(catalog_box)
        action_row.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Button(action_row, text="Cargar Excel", command=self.load_spreadsheet).pack(side="left")
        self.catalog_count = ttk.Label(action_row, text="")
        self.catalog_count.pack(side="right")
        self.catalog_filter = tk.StringVar()
        filter_entry = ttk.Entry(catalog_box, textvariable=self.catalog_filter)
        filter_entry.pack(fill="x", padx=8, pady=4)
        filter_entry.bind("<KeyRelease>", lambda _event: self._load_catalog_tree())
        tree_frame = ttk.Frame(catalog_box)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=(4, 8))
        self.catalog_tree = ttk.Treeview(tree_frame, columns=("type", "server"), show="tree headings", selectmode="browse")
        self.catalog_tree.heading("#0", text="Calendar Name")
        self.catalog_tree.heading("type", text="Type")
        self.catalog_tree.heading("server", text="Server")
        self.catalog_tree.column("#0", width=145, stretch=True)
        self.catalog_tree.column("type", width=78, anchor="center")
        self.catalog_tree.column("server", width=95, anchor="center")
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.catalog_tree.yview)
        self.catalog_tree.configure(yscrollcommand=scrollbar.set)
        self.catalog_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.catalog_tree.bind("<Double-1>", self._use_selected_calendar)

    def _build_right(self, parent):
        header = tk.Frame(parent, bg="#D7E1F3", height=40)
        header.pack(fill="x", pady=(8, 0))
        header.pack_propagate(False)
        tk.Label(
            header, text="Scheduling", bg="#D7E1F3", fg=COLORS["navy_dark"],
            font=("Segoe UI", 11, "bold"), padx=12,
        ).pack(side="left", fill="y")
        ttk.Button(header, text="Copiar", command=self.copy_configuration).pack(side="right", padx=6, pady=5)

        notebook = ttk.Notebook(parent)
        notebook.pack(fill="both", expand=True)
        schedule_tab = ttk.Frame(notebook)
        matches_tab = ttk.Frame(notebook)
        notebook.add(schedule_tab, text="Scheduling")
        notebook.add(matches_tab, text="Coincidencias")

        self.schedule_text = ScrolledText(
            schedule_tab, wrap="word", bg="white", fg=COLORS["text"],
            relief="flat", font=("Consolas", 9), padx=10, pady=10,
        )
        self.schedule_text.pack(fill="both", expand=True, padx=1, pady=1)
        self.schedule_text.tag_configure("section", foreground=COLORS["navy_dark"], font=("Segoe UI", 10, "bold"), spacing1=10, spacing3=4)
        self.schedule_text.tag_configure("label", foreground=COLORS["muted"], font=("Segoe UI", 9, "bold"))
        self.schedule_text.tag_configure("value", foreground=COLORS["text"], font=("Segoe UI", 9))
        self.schedule_text.tag_configure("warning", foreground=COLORS["warning"], font=("Segoe UI", 9, "bold"))
        self.schedule_text.configure(state="disabled")

        self.matches_tree = ttk.Treeview(matches_tab, columns=("type", "server", "score", "definition"), show="tree headings")
        for key, title, width in (
            ("#0", "Calendario", 145), ("type", "Tipo", 75), ("server", "Servidor", 100),
            ("score", "Afinidad", 65), ("definition", "Regla", 65),
        ):
            self.matches_tree.heading(key, text=title)
            self.matches_tree.column(key, width=width, anchor="center" if key != "#0" else "w")
        self.matches_tree.pack(fill="both", expand=True, padx=6, pady=6)
        self.matches_tree.bind("<Double-1>", self._use_match)
        tk.Label(
            matches_tab,
            text="Doble clic para simular el calendario. ‘Regla: Sí’ significa que hay definición conocida; el resto son sugerencias por catálogo.",
            bg=COLORS["blue_light"], fg=COLORS["navy_dark"], wraplength=370, justify="left", padx=8, pady=7,
        ).pack(fill="x", padx=6, pady=(0, 6))

    def _set_year(self, year: int):
        self.year = max(2000, min(2100, year))
        self.analyze()

    def _use_example(self, _event=None):
        value = self.examples.get()
        self.query_text.delete("1.0", "end")
        self.query_text.insert("1.0", value)
        self.analyze()

    def _load_catalog_tree(self):
        filter_value = self.catalog_filter.get().strip().upper() if hasattr(self, "catalog_filter") else ""
        for item in self.catalog_tree.get_children():
            self.catalog_tree.delete(item)
        visible = 0
        for index, record in enumerate(self.catalog.records):
            haystack = f"{record.name} {record.calendar_type} {record.server}".upper()
            if filter_value and filter_value not in haystack:
                continue
            self.catalog_tree.insert("", "end", iid=f"cal-{index}", text=record.name, values=(record.calendar_type, record.server))
            visible += 1
        self.catalog_count.configure(text=f"{visible}/{len(self.catalog.records)}")

    def load_spreadsheet(self):
        path = filedialog.askopenfilename(
            title="Seleccionar catálogo de calendarios",
            filetypes=[("Excel o CSV", "*.xls *.xlsx *.csv"), ("Todos los archivos", "*.*")],
        )
        if not path:
            return
        try:
            loaded = CalendarCatalog.from_spreadsheet(path, self.catalog.definitions)
        except Exception as exc:
            messagebox.showerror("No se pudo cargar", str(exc))
            return
        self.catalog = loaded
        self._load_catalog_tree()
        self.status.set(f"Catálogo cargado: {path} | {len(loaded.records)} registros")
        self.analyze()

    def _selected_catalog_record(self):
        selected = self.catalog_tree.selection()
        if not selected:
            return None
        index = int(selected[0].split("-")[-1])
        return self.catalog.records[index]

    def _use_selected_calendar(self, _event=None):
        record = self._selected_catalog_record()
        if not record:
            return
        self.query_text.delete("1.0", "end")
        self.query_text.insert("1.0", f"Usar calendario {record.name}")
        self.analyze()

    def _use_match(self, _event=None):
        selected = self.matches_tree.selection()
        if not selected or not self.proposal:
            return
        index = int(selected[0].split("-")[-1])
        match = self.proposal.matches[index]
        self.query_text.delete("1.0", "end")
        self.query_text.insert("1.0", f"Usar calendario {match.record.name}")
        self.analyze()

    def analyze(self):
        query = self.query_text.get("1.0", "end").strip()
        if not query:
            messagebox.showwarning("Petición vacía", "Escribe una petición de calendario.")
            return
        try:
            self.proposal = interpret(query, self.year, self.catalog)
        except Exception as exc:
            messagebox.showerror("Error de interpretación", str(exc))
            return
        self.calendar_view.set_data(self.year, self.proposal.selected_dates)
        self._show_proposal(self.proposal)
        self.status.set(
            f"{self.proposal.title} | {len(self.proposal.selected_dates)} fechas | "
            f"Confianza {self.proposal.confidence} | {len(self.catalog.records)} calendarios en catálogo"
        )

    def _insert_field(self, label: str, value: str):
        self.schedule_text.insert("end", label + "\n", "label")
        self.schedule_text.insert("end", (value or "—") + "\n", "value")

    def _show_proposal(self, proposal: ScheduleProposal):
        text = self.schedule_text
        text.configure(state="normal")
        text.delete("1.0", "end")
        text.insert("end", "Resultado interpretado\n", "section")
        self._insert_field("Petición", proposal.query)
        self._insert_field("Interpretación", proposal.title)
        self._insert_field("Confianza", proposal.confidence)
        self._insert_field("Explicación", proposal.explanation)
        self._insert_field("Calendario existente reutilizable", proposal.reusable_calendar)
        self._insert_field("Comprobación del catálogo", proposal.reuse_status)
        text.insert("end", "\nConfiguración Control-M\n", "section")
        self._insert_field("Schedule", proposal.schedule_type)
        self._insert_field("Days of month", ", ".join(proposal.days_of_month))
        self._insert_field("Days of week", ", ".join(proposal.days_of_week))
        self._insert_field("Order on Months", ", ".join(MONTH_NAMES[m - 1][:3] for m in proposal.months))
        self._insert_field("Based on Calendar", proposal.based_on_mode)
        self._insert_field("Regular Calendar", proposal.regular_calendar)
        self._insert_field("Rule", proposal.calendar_rule)
        self._insert_field("Relationship", proposal.relationship if proposal.rule_based_calendars else "")
        self._insert_field("Included Rule-based Calendars", ", ".join(proposal.rule_based_calendars))
        self._insert_field("Excluded Rule-based Calendars", ", ".join(proposal.excluded_rule_based_calendars))
        self._insert_field("Fechas simuladas", str(len(proposal.selected_dates)))
        if proposal.assumptions:
            text.insert("end", "\nSupuestos\n", "section")
            for item in proposal.assumptions:
                text.insert("end", "• " + item + "\n", "warning")
        if proposal.warnings:
            text.insert("end", "\nRevisión necesaria\n", "section")
            for item in proposal.warnings:
                text.insert("end", "• " + item + "\n", "warning")
        text.configure(state="disabled")

        for item in self.matches_tree.get_children():
            self.matches_tree.delete(item)
        for index, match in enumerate(proposal.matches):
            self.matches_tree.insert(
                "", "end", iid=f"match-{index}", text=match.record.name,
                values=(match.record.calendar_type, match.record.server, f"{match.score:.0f}", "Sí" if match.exact_definition else "No"),
            )

    def copy_configuration(self):
        if not self.proposal:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(self.proposal.control_m_summary())
        self.status.set("Configuración copiada al portapapeles")
