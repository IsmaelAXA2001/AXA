from __future__ import annotations

import calendar
from datetime import date, timedelta


NATIONAL_HOLIDAYS_2026 = {
    date(2026, 1, 1),
    date(2026, 1, 6),
    date(2026, 4, 3),
    date(2026, 5, 1),
    date(2026, 8, 15),
    date(2026, 10, 12),
    date(2026, 11, 1),
    date(2026, 12, 6),
    date(2026, 12, 8),
    date(2026, 12, 25),
}


def iter_year(year: int):
    current = date(year, 1, 1)
    end = date(year, 12, 31)
    while current <= end:
        yield current
        current += timedelta(days=1)


def every_day(year: int) -> set[date]:
    return set(iter_year(year))


def weekdays(year: int, selected_weekdays: set[int], months: set[int] | None = None) -> set[date]:
    allowed_months = months or set(range(1, 13))
    return {d for d in iter_year(year) if d.month in allowed_months and d.weekday() in selected_weekdays}


def month_days(year: int, day_numbers: set[int], months: set[int] | None = None) -> set[date]:
    allowed_months = months or set(range(1, 13))
    result: set[date] = set()
    for month in allowed_months:
        last = calendar.monthrange(year, month)[1]
        for day_number in day_numbers:
            if 1 <= day_number <= last:
                result.add(date(year, month, day_number))
    return result


def nth_weekday_of_month(year: int, weekday: int, nth: int) -> set[date]:
    result: set[date] = set()
    for month in range(1, 13):
        candidates = [
            date(year, month, day)
            for day in range(1, calendar.monthrange(year, month)[1] + 1)
            if date(year, month, day).weekday() == weekday
        ]
        if nth > 0 and len(candidates) >= nth:
            result.add(candidates[nth - 1])
        elif nth < 0 and len(candidates) >= abs(nth):
            result.add(candidates[nth])
    return result


def business_days(year: int, holidays: set[date] | None = None) -> set[date]:
    holiday_set = holidays or set()
    return {d for d in iter_year(year) if d.weekday() < 5 and d not in holiday_set}


def business_day_from_month_end(year: int, ordinal: int, holidays: set[date] | None = None) -> set[date]:
    holiday_set = holidays or set()
    result: set[date] = set()
    for month in range(1, 13):
        candidates = [
            date(year, month, day)
            for day in range(1, calendar.monthrange(year, month)[1] + 1)
            if date(year, month, day).weekday() < 5 and date(year, month, day) not in holiday_set
        ]
        if len(candidates) >= ordinal:
            result.add(candidates[-ordinal])
    return result


def business_day_from_month_start(year: int, ordinal: int, holidays: set[date] | None = None) -> set[date]:
    holiday_set = holidays or set()
    result: set[date] = set()
    for month in range(1, 13):
        candidates = [
            date(year, month, day)
            for day in range(1, calendar.monthrange(year, month)[1] + 1)
            if date(year, month, day).weekday() < 5 and date(year, month, day) not in holiday_set
        ]
        if len(candidates) >= ordinal:
            result.add(candidates[ordinal - 1])
    return result


def month_end_not_sunday(year: int) -> set[date]:
    """Regla observada en CALCIERR: último día, salvo domingo -> sábado anterior."""
    result: set[date] = set()
    for month in range(1, 13):
        d = date(year, month, calendar.monthrange(year, month)[1])
        if d.weekday() == 6:
            d -= timedelta(days=1)
        result.add(d)
    return result


def shift_dates(values: set[date], days: int, year: int) -> set[date]:
    return {shifted for d in values if (shifted := d + timedelta(days=days)).year == year}


def dates_for_definition(definition: dict, year: int) -> tuple[set[date], list[str]]:
    kind = definition.get("kind", "unknown")
    warnings: list[str] = []
    if kind == "every_day":
        return every_day(year), warnings
    if kind == "weekdays":
        return weekdays(year, set(definition.get("weekdays", []))), warnings
    if kind == "nth_weekday":
        return nth_weekday_of_month(year, int(definition["weekday"]), int(definition["nth"])), warnings
    if kind == "nth_weekday_union":
        result: set[date] = set()
        for item in definition.get("rules", []):
            result |= nth_weekday_of_month(year, int(item["weekday"]), int(item["nth"]))
        return result, warnings
    if kind == "month_end_not_sunday":
        return month_end_not_sunday(year), warnings
    if kind == "national_holidays":
        dates = definition.get("dates_by_year", {}).get(str(year), [])
        if not dates:
            warnings.append(f"No hay fechas cargadas para {year}; el catálogo solo confirma el nombre del calendario.")
            return set(), warnings
        return {date.fromisoformat(value) for value in dates}, warnings
    if kind == "business_days_national":
        if year != 2026:
            warnings.append(f"Los festivos nacionales exactos solo están cargados para 2026; para {year} se muestran lunes a viernes sin descontar festivos.")
            return business_days(year), warnings
        return business_days(year, NATIONAL_HOLIDAYS_2026), warnings
    warnings.append("La regla interna de este calendario no está disponible en el Excel aportado.")
    return set(), warnings
