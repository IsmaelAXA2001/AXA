from pathlib import Path


APP_TITLE = "Control-M Calendar Assistant v1"
ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
CATALOG_PATH = DATA_DIR / "calendarios_catalogo.json"
DEFINITIONS_PATH = DATA_DIR / "calendar_definitions.json"

# Paleta inspirada en la pantalla de Control-M aportada como referencia.
COLORS = {
    "navy": "#005E99",
    "navy_dark": "#004A79",
    "blue": "#5A9FD0",
    "blue_light": "#DDECF6",
    "panel": "#EEF3F7",
    "surface": "#FFFFFF",
    "line": "#B8C8D4",
    "text": "#1C2A35",
    "muted": "#687985",
    "selected": "#F2A13A",
    "selected_dark": "#D98212",
    "success": "#2B8A67",
    "warning": "#B56A00",
    "error": "#B63A3A",
}

MONTH_NAMES = [
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
]
WEEKDAY_LABELS = ["L", "M", "X", "J", "V", "S", "D"]
WEEKDAY_NAMES = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
