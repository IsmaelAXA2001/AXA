"""Genera una vista previa estática de la dirección visual de la interfaz."""

from __future__ import annotations

import calendar
from datetime import date
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


OUT = Path(__file__).resolve().parent.parent / "docs" / "vista_previa_controlm_calendarios_v1.png"
W, H = 1500, 860
COLORS = {
    "navy": "#005E99", "navy_dark": "#004A79", "blue": "#5A9FD0",
    "blue_light": "#DDECF6", "panel": "#EEF3F7", "surface": "#FFFFFF",
    "line": "#B8C8D4", "text": "#1C2A35", "muted": "#687985",
    "selected": "#F2A13A", "warning": "#B56A00",
}
MONTHS = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]


def font(size, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def box(draw, xy, fill, outline=None, width=1, radius=0):
    if radius:
        draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)
    else:
        draw.rectangle(xy, fill=fill, outline=outline, width=width)


def text(draw, xy, value, size=12, color=None, bold=False, anchor=None):
    draw.text(xy, value, font=font(size, bold), fill=color or COLORS["text"], anchor=anchor)


def month_card(draw, x, y, width, height, month, selected):
    box(draw, (x, y, x + width, y + height), COLORS["surface"], COLORS["line"])
    box(draw, (x, y, x + width, y + 25), COLORS["blue"])
    text(draw, (x + width / 2, y + 13), f"{MONTHS[month - 1]} 2026", 11, "white", True, "mm")
    for col, label in enumerate("LMXJVSD"):
        text(draw, (x + 18 + col * ((width - 36) / 6), y + 37), label, 9, COLORS["text"], True, "mm")
    cal = calendar.Calendar(firstweekday=0)
    weeks = cal.monthdayscalendar(2026, month)
    while len(weeks) < 6:
        weeks.append([0] * 7)
    cell_w = (width - 20) / 7
    cell_h = (height - 48) / 6
    for row, week in enumerate(weeks):
        for col, day in enumerate(week):
            if not day:
                continue
            cx = x + 10 + col * cell_w
            cy = y + 48 + row * cell_h
            selected_day = date(2026, month, day) in selected
            if selected_day:
                box(draw, (cx + 2, cy + 1, cx + cell_w - 2, cy + cell_h - 1), COLORS["selected"], radius=2)
            text(draw, (cx + cell_w / 2, cy + cell_h / 2), str(day), 8, "#5B3400" if selected_day else COLORS["muted"], selected_day, "mm")


def main():
    image = Image.new("RGB", (W, H), COLORS["panel"])
    draw = ImageDraw.Draw(image)

    box(draw, (0, 0, W, 54), COLORS["navy"])
    text(draw, (18, 27), "Control-M", 20, "white", True, "lm")
    text(draw, (142, 27), "Calendar Assistant  |  búsqueda y simulación de Scheduling", 12, "#DCEFFF", False, "lm")
    box(draw, (1455, 0, W, 54), COLORS["navy_dark"])
    text(draw, (1477, 27), "v1", 11, "white", True, "mm")

    left_x, left_w = 10, 292
    center_x, center_w = 310, 790
    right_x, right_w = 1108, 382

    box(draw, (left_x, 64, left_x + left_w, 838), COLORS["panel"], COLORS["line"])
    text(draw, (left_x + 12, 84), "Petición del usuario", 11, COLORS["navy_dark"], True)
    box(draw, (left_x + 12, 104, left_x + left_w - 12, 170), "white", COLORS["line"], radius=4)
    text(draw, (left_x + 22, 116), "Todos los lunes del mes", 12)
    box(draw, (left_x + 12, 180, left_x + left_w - 12, 216), COLORS["navy"], radius=4)
    text(draw, (left_x + left_w / 2, 198), "Analizar y mostrar", 11, "white", True, "mm")
    text(draw, (left_x + 12, 244), "Calendarios existentes", 11, COLORS["navy_dark"], True)
    box(draw, (left_x + 12, 265, left_x + left_w - 12, 298), "white", COLORS["line"], radius=3)
    text(draw, (left_x + 22, 282), "Filtrar por nombre, tipo o servidor", 9, COLORS["muted"], False, "lm")
    headers = ["Calendar Name", "Type", "Server"]
    col_x = [left_x + 12, left_x + 155, left_x + 220]
    box(draw, (left_x + 12, 307, left_x + left_w - 12, 333), COLORS["blue_light"])
    for i, label in enumerate(headers):
        text(draw, (col_x[i] + 4, 320), label, 8, COLORS["navy_dark"], True, "lm")
    rows = [
        ("ALLDAYS", "Regular", "All"), ("CALCIERR", "Regular", "All"),
        ("DOMINGOS", "Regular", "All"), ("FESTIVOSNAC", "Regular", "All"),
        ("LABORABL", "Regular", "All"), ("TERCER_LUNES", "Regular", "All"),
        ("TERCER_LUNES", "Rule-based", "All"), ("WEEKDAYS", "Regular", "All"),
    ]
    for idx, row in enumerate(rows):
        y = 334 + idx * 31
        box(draw, (left_x + 12, y, left_x + left_w - 12, y + 30), "#F8FBFD" if idx % 2 == 0 else "white", COLORS["line"])
        for i, value in enumerate(row):
            text(draw, (col_x[i] + 4, y + 15), value, 8, COLORS["text"], False, "lm")
    text(draw, (left_x + 18, 812), "90 registros  |  88 nombres únicos", 9, COLORS["muted"])

    box(draw, (center_x, 64, center_x + center_w, 838), COLORS["panel"], COLORS["line"])
    box(draw, (center_x + 10, 74, center_x + center_w - 10, 114), "#D7E1F3")
    text(draw, (center_x + 28, 94), "‹", 24, COLORS["navy"], True, "mm")
    text(draw, (center_x + 62, 94), "2026", 12, COLORS["text"], True, "mm")
    text(draw, (center_x + 96, 94), "›", 24, COLORS["navy"], True, "mm")
    text(draw, (center_x + center_w - 30, 94), "52 fechas", 10, COLORS["muted"], False, "rm")

    selected = {d for month in range(1, 13) for day in range(1, calendar.monthrange(2026, month)[1] + 1) if (d := date(2026, month, day)).weekday() == 0}
    gap = 8
    card_w = (center_w - 20 - gap * 5) / 4
    card_h = (838 - 126 - gap * 4) / 3
    for month in range(1, 13):
        row, col = divmod(month - 1, 4)
        x = center_x + 10 + gap + col * (card_w + gap)
        y = 126 + gap + row * (card_h + gap)
        month_card(draw, x, y, card_w, card_h, month, selected)

    box(draw, (right_x, 64, right_x + right_w, 838), COLORS["surface"], COLORS["line"])
    box(draw, (right_x, 64, right_x + right_w, 105), "#D7E1F3")
    text(draw, (right_x + 14, 85), "Scheduling", 13, COLORS["navy_dark"], True, "lm")
    box(draw, (right_x + right_w - 72, 72, right_x + right_w - 12, 97), "#E7EEF4", COLORS["line"], radius=3)
    text(draw, (right_x + right_w - 42, 85), "Copiar", 9, COLORS["text"], True, "mm")
    box(draw, (right_x, 105, right_x + 116, 138), COLORS["selected"])
    box(draw, (right_x + 116, 105, right_x + 240, 138), "#DCE6ED")
    text(draw, (right_x + 58, 121), "Scheduling", 9, "#4D2C00", True, "mm")
    text(draw, (right_x + 178, 121), "Coincidencias", 9, COLORS["text"], False, "mm")

    fields = [
        ("Resultado interpretado", ""),
        ("Petición", "Todos los lunes del mes"),
        ("Interpretación", "Todos los lunes"),
        ("Confianza", "Alta"),
        ("Calendario reutilizable", "No confirmado con las definiciones disponibles"),
        ("Configuración Control-M", ""),
        ("Schedule", "Week Days"),
        ("Days of month", "—"),
        ("Days of week", "Lunes"),
        ("Order on Months", "Ene, Feb, Mar, Abr, May, Jun, Jul, Ago, Sep, Oct, Nov, Dic"),
        ("Based on Calendar", "—"),
        ("Regular Calendar", "—"),
        ("Fechas simuladas", "52"),
    ]
    y = 154
    for label, value in fields:
        if not value:
            text(draw, (right_x + 16, y), label, 11, COLORS["navy_dark"], True)
            y += 30
        else:
            text(draw, (right_x + 16, y), label, 8, COLORS["muted"], True)
            y += 16
            # Ajuste simple para el campo largo de meses.
            if len(value) > 55:
                first = value[:55].rsplit(" ", 1)[0]
                second = value[len(first):].strip()
                text(draw, (right_x + 16, y), first, 9)
                text(draw, (right_x + 16, y + 15), second, 9)
                y += 38
            else:
                text(draw, (right_x + 16, y), value, 10)
                y += 30
    box(draw, (right_x + 12, 730, right_x + right_w - 12, 817), "#FFF4DF", "#E6C27C", radius=4)
    text(draw, (right_x + 24, 748), "Explicación", 10, COLORS["warning"], True)
    text(draw, (right_x + 24, 771), "Planificación directa por día de la semana;", 9)
    text(draw, (right_x + 24, 789), "no necesita un calendario regular.", 9)

    box(draw, (0, 840, W, H), COLORS["navy_dark"])
    text(draw, (12, 850), "Todos los lunes  |  52 fechas  |  Confianza Alta  |  90 calendarios en catálogo", 9, "white", False, "lm")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    image.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
