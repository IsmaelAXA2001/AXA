import unittest
from datetime import date
from pathlib import Path

from app.calendar_catalog import CalendarCatalog
from app.interpreter import interpret


ROOT = Path(__file__).resolve().parent.parent


class InterpreterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = CalendarCatalog.from_json(
            ROOT / "data" / "calendarios_catalogo.json",
            ROOT / "data" / "calendar_definitions.json",
        )

    def test_all_mondays(self):
        result = interpret("Todos los lunes del mes", 2026, self.catalog)
        self.assertEqual(result.schedule_type, "Week Days")
        self.assertEqual(result.days_of_week, ["Lunes"])
        self.assertTrue(all(value.weekday() == 0 for value in result.selected_dates))
        self.assertEqual(result.matches[0].record.name, "TERCER_LUNES")
        self.assertFalse(result.reusable_calendar)

    def test_known_schedule_is_identified_as_reusable(self):
        result = interpret("Todos los domingos", 2026, self.catalog)
        self.assertEqual(result.reusable_calendar, "DOMINGOS")
        self.assertIn("existente", result.reuse_status.lower())

    def test_labour_calendar_excludes_known_holidays(self):
        result = interpret("Días laborables según calendario LABORABL", 2026, self.catalog)
        self.assertNotIn(date(2026, 1, 1), result.selected_dates)
        self.assertNotIn(date(2026, 1, 6), result.selected_dates)
        self.assertIn(date(2026, 1, 2), result.selected_dates)

    def test_calcierr_may_uses_previous_saturday(self):
        result = interpret("Usar calendario CALCIERR", 2026, self.catalog)
        self.assertIn(date(2026, 5, 30), result.selected_dates)
        self.assertNotIn(date(2026, 5, 31), result.selected_dates)

    def test_day_before_calcierr(self):
        result = interpret("Un día antes de los cierres según CALCIERR", 2026, self.catalog)
        self.assertIn(date(2026, 5, 29), result.selected_dates)
        self.assertEqual(result.offset_days, -1)

    def test_penultimate_business_day(self):
        result = interpret("Penúltimo día laborable de cada mes", 2026, self.catalog)
        self.assertEqual(result.days_of_month, ["L2"])
        self.assertEqual(len(result.selected_dates), 12)

    def test_penultimate_not_weekend(self):
        result = interpret("Penúltimo día del mes que no sea sábado ni domingo", 2026, self.catalog)
        self.assertEqual(result.days_of_month, ["L2"])
        self.assertEqual(len(result.selected_dates), 12)

    def test_quarterly_day_15(self):
        result = interpret("Ejecución cada 3 meses los días 15", 2026, self.catalog)
        self.assertEqual(result.months, [1, 4, 7, 10])
        self.assertEqual(len(result.selected_dates), 4)

    def test_two_sundays_every_two_weeks(self):
        result = interpret("Dos domingos al mes cada dos semanas", 2026, self.catalog)
        self.assertEqual(result.schedule_type, "Advanced Scheduling")
        self.assertEqual(result.calendar_rule, "W1/Domingo + W3/Domingo")
        self.assertEqual(len(result.selected_dates), 24)
        self.assertEqual(result.reusable_calendar, "CADA2DOM")


if __name__ == "__main__":
    unittest.main()
