@echo off
setlocal
cd /d "%~dp0"
py -m pip install pyinstaller
py -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name ControlM_Calendarios_v1 ^
  --add-data "data;data" ^
  main.py
if errorlevel 1 (
  echo.
  echo No se ha podido crear el ejecutable.
  pause
) else (
  echo.
  echo Ejecutable creado en dist\ControlM_Calendarios_v1.exe
  pause
)
endlocal
