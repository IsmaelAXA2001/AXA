from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any


@dataclass(frozen=True)
class CalendarRecord:
    name: str
    server: str
    calendar_type: str
    synchronization_state: str = ""
    last_synchronized: str = ""
    source: str = "Catálogo Excel"


@dataclass
class CalendarMatch:
    record: CalendarRecord
    score: float
    reason: str
    exact_definition: bool = False


@dataclass
class ScheduleProposal:
    query: str
    year: int
    title: str
    schedule_type: str
    selected_dates: set[date] = field(default_factory=set)
    days_of_month: list[str] = field(default_factory=list)
    days_of_week: list[str] = field(default_factory=list)
    months: list[int] = field(default_factory=lambda: list(range(1, 13)))
    regular_calendar: str = ""
    based_on_mode: str = ""
    calendar_rule: str = ""
    rule_based_calendars: list[str] = field(default_factory=list)
    excluded_rule_based_calendars: list[str] = field(default_factory=list)
    relationship: str = "OR"
    offset_days: int = 0
    confidence: str = "Media"
    explanation: str = ""
    warnings: list[str] = field(default_factory=list)
    matches: list[CalendarMatch] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    reusable_calendar: str = ""
    reuse_status: str = "No confirmado"
    raw: dict[str, Any] = field(default_factory=dict)

    def control_m_summary(self) -> str:
        lines = [
            f"Schedule: {self.schedule_type}",
            f"Año de simulación: {self.year}",
            f"Order on Months: {', '.join(str(m) for m in self.months) if self.months else 'Ninguno'}",
        ]
        if self.days_of_month:
            lines.append("Days of month: " + ", ".join(self.days_of_month))
        if self.days_of_week:
            lines.append("Days of week: " + ", ".join(self.days_of_week))
        if self.based_on_mode:
            lines.append("Based on Calendar: " + self.based_on_mode)
        if self.regular_calendar:
            lines.append("Regular Calendar: " + self.regular_calendar)
        if self.calendar_rule:
            lines.append("Calendar rule: " + self.calendar_rule)
        lines.append("Calendario reutilizable: " + (self.reusable_calendar or "No confirmado"))
        lines.append("Estado de reutilización: " + self.reuse_status)
        if self.offset_days:
            lines.append(f"Desplazamiento calculado: {self.offset_days:+d} día(s)")
        if self.rule_based_calendars:
            lines.append("Included Rule-based Calendars: " + ", ".join(self.rule_based_calendars))
        if self.excluded_rule_based_calendars:
            lines.append("Excluded Rule-based Calendars: " + ", ".join(self.excluded_rule_based_calendars))
        if self.rule_based_calendars or self.excluded_rule_based_calendars:
            lines.append("Relationship: " + self.relationship)
        lines.append(f"Fechas mostradas: {len(self.selected_dates)}")
        lines.append(f"Confianza: {self.confidence}")
        if self.assumptions:
            lines.append("Supuestos: " + " | ".join(self.assumptions))
        if self.warnings:
            lines.append("Revisión necesaria: " + " | ".join(self.warnings))
        return "\n".join(lines)
