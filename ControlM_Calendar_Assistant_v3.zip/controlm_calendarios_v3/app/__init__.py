"""Aplicación de consulta y simulación de calendarios Control-M."""

__version__ = "1.0.0"
