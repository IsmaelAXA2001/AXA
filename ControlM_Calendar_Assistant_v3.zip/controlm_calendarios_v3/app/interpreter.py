from __future__ import annotations

import re
import unicodedata
from datetime import date

from app.calendar_catalog import CalendarCatalog, normalize
from app.config import WEEKDAY_NAMES
from app.models import ScheduleProposal
from app.query_parser import (
    EXCLUSION_MARKER,
    extract_day_numbers,
    extract_months,
    extract_ordinals,
    extract_weekday_constraints,
    relationship_from_text,
)
from app.schedule_engine import (
    NATIONAL_HOLIDAYS_2026,
    business_day_from_month_end,
    business_day_from_month_start,
    business_days,
    dates_for_definition,
    every_day,
    month_days,
    nth_weekday_of_month,
    shift_dates,
    weekdays,
)


DAY_WORDS = {
    "LUNES": 0,
    "MARTES": 1,
    "MIERCOLES": 2,
    "JUEVES": 3,
    "VIERNES": 4,
    "SABADO": 5,
    "SABADOS": 5,
    "DOMINGO": 6,
    "DOMINGOS": 6,
}


def _norm(value: str) -> str:
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", value.upper()).strip()


def _national_holidays(year: int) -> set[date]:
    return NATIONAL_HOLIDAYS_2026 if year == 2026 else set()


def _decorate(proposal: ScheduleProposal, catalog: CalendarCatalog) -> ScheduleProposal:
    proposal.matches = catalog.search(proposal.query)
    if proposal.reusable_calendar:
        return proposal
    if proposal.selected_dates:
        exact_names: list[str] = []
        for name, definition in catalog.definitions.items():
            values, warnings = dates_for_definition(definition, proposal.year)
            if not warnings and values == proposal.selected_dates and catalog.find_exact(name):
                exact_names.append(name)
        if exact_names:
            proposal.reusable_calendar = exact_names[0]
            proposal.reuse_status = "Coincidencia exacta por fechas y regla conocida"
            proposal.matches.sort(
                key=lambda match: (
                    normalize(match.record.name).replace(" ", "")
                    != normalize(proposal.reusable_calendar).replace(" ", ""),
                    -match.score,
                )
            )
        else:
            proposal.reuse_status = "No hay coincidencia exacta confirmable con las definiciones disponibles"
    return proposal


def _from_known_calendar(
    query: str,
    year: int,
    calendar_name: str,
    catalog: CalendarCatalog,
    offset: int = 0,
    allowed_months: set[int] | None = None,
) -> ScheduleProposal:
    definition = catalog.definition(calendar_name)
    matches = catalog.find_exact(calendar_name)
    if definition:
        dates, warnings = dates_for_definition(definition, year)
        if allowed_months is not None:
            dates = {value for value in dates if value.month in allowed_months}
        if offset:
            dates = shift_dates(dates, offset, year)
        proposal = ScheduleProposal(
            query=query,
            year=year,
            title=f"Calendario {calendar_name}",
            schedule_type="Based on Calendar",
            selected_dates=dates,
            regular_calendar=calendar_name,
            based_on_mode="Calendar Days",
            calendar_rule="Order only on calendar days",
            offset_days=offset,
            confidence=str(definition.get("confidence", "Alta")),
            explanation=str(definition.get("description", "Calendario existente con regla conocida.")),
            warnings=warnings,
            reusable_calendar=calendar_name,
            reuse_status="Calendario existente seleccionado; regla interna conocida",
            months=sorted(allowed_months or set(range(1, 13))),
        )
        if offset:
            proposal.warnings.append("El desplazamiento se simula sobre las fechas del calendario; valide en Control-M si debe implementarse como regla relativa, calendario derivado o confirmación/shift.")
    else:
        proposal = ScheduleProposal(
            query=query,
            year=year,
            title=f"Calendario {calendar_name}",
            schedule_type="Based on Calendar",
            regular_calendar=calendar_name,
            based_on_mode="Calendar Days",
            calendar_rule="Order only on calendar days",
            offset_days=offset,
            confidence="Baja",
            explanation="El calendario figura en el catálogo, pero el Excel no contiene sus fechas ni su regla interna.",
            warnings=["Importe una definición JSON o un export con fechas para obtener una vista anual exacta."],
            reusable_calendar=calendar_name,
            reuse_status="Existe en el catálogo, pero su regla interna no está disponible",
            months=sorted(allowed_months or set(range(1, 13))),
        )
    if len(matches) > 1:
        proposal.warnings.append(f"Hay {len(matches)} registros con el nombre {calendar_name}; revise tipo y servidor.")
    return _decorate(proposal, catalog)


def interpret(query: str, year: int, catalog: CalendarCatalog) -> ScheduleProposal:
    text = _norm(query)
    mentioned = catalog.names_mentioned(query)
    month_selection = extract_months(text)
    allowed_months = month_selection.months
    day_numbers = extract_day_numbers(text)
    selected_weekdays, excluded_weekdays = extract_weekday_constraints(text)
    ordinals = extract_ordinals(text)
    offset = 0
    before = re.search(r"(?:UN|1)\s+DIA\s+ANTES", text)
    after = re.search(r"(?:UN|1)\s+DIA\s+DESPUES", text)
    generic_offset = re.search(r"(\d+)\s+DIAS?\s+(ANTES|DESPUES)", text)
    if before:
        offset = -1
    elif after:
        offset = 1
    elif generic_offset:
        offset = int(generic_offset.group(1)) * (-1 if generic_offset.group(2) == "ANTES" else 1)
    # Cuando LABORABL forma parte de una regla ordinal (L1/L2/D1), el nombre
    # identifica el calendario base pero no constituye toda la planificación.
    relative_labour_rule = (
        mentioned
        and normalize(mentioned[0]).replace(" ", "") == "LABORABL"
        and any(word in text for word in ("PENULTIMO", "ULTIMO", "PRIMER"))
    )
    biweekly_sunday_rule = (
        mentioned
        and normalize(mentioned[0]).replace(" ", "") == "DOMINGOS"
        and ("CADA DOS SEMANAS" in text or "CADA 2 SEMANAS" in text or "DOS DOMINGOS" in text)
    )
    normalized_query = normalize(query)
    exclusion = re.search(rf"\b{EXCLUSION_MARKER}\b", normalized_query)
    mentioned_position = normalized_query.find(normalize(mentioned[0])) if mentioned else -1
    calendar_is_excluded = bool(exclusion and mentioned_position > exclusion.start())
    mentioned_definition = catalog.definition(mentioned[0]) if mentioned else None
    definition_weekdays = (
        set(mentioned_definition.get("weekdays", []))
        if mentioned_definition and mentioned_definition.get("kind") == "weekdays"
        else set()
    )
    calendar_weekday_conflict = bool(
        selected_weekdays
        and (not definition_weekdays or definition_weekdays != selected_weekdays)
    )
    if (
        mentioned
        and not relative_labour_rule
        and not biweekly_sunday_rule
        and not day_numbers
        and not ordinals
        and not calendar_is_excluded
        and not calendar_weekday_conflict
    ):
        return _from_known_calendar(
            query,
            year,
            mentioned[0],
            catalog,
            offset,
            allowed_months if month_selection.explicit else None,
        )

    # Días laborables relativos al inicio o final del mes.
    if "LABORABL" in text and any(word in text for word in ("PENULTIMO", "ULTIMO", "PRIMER")):
        holidays = _national_holidays(year)
        if "PENULTIMO" in text:
            dates = business_day_from_month_end(year, 2, holidays)
            token = "L2"
            title = "Penúltimo día laborable de cada mes"
        elif "ULTIMO" in text:
            dates = business_day_from_month_end(year, 1, holidays)
            token = "L1"
            title = "Último día laborable de cada mes"
        else:
            dates = business_day_from_month_start(year, 1, holidays)
            token = "D1"
            title = "Primer día laborable de cada mes"
        dates = {value for value in dates if value.month in allowed_months}
        proposal = ScheduleProposal(
            query=query, year=year, title=title, schedule_type="Based on Calendar",
            selected_dates=dates, days_of_month=[token], regular_calendar="LABORABL",
            based_on_mode="Month Days (Dependent on Calendar)",
            calendar_rule=f"Order on {token} working day of each month",
            confidence="Alta" if year == 2026 else "Media",
            explanation="Se toma el ordinal sobre los días existentes en el calendario LABORABL.",
            months=sorted(allowed_months),
            assumptions=list(month_selection.assumptions),
        )
        if year != 2026:
            proposal.warnings.append("Los festivos exactos solo están cargados para 2026; revise el calendario LABORABL del año seleccionado.")
        return _decorate(proposal, catalog)

    # Días concretos del mes, con meses, días de semana o calendario base opcionales.
    # Esta regla debe evaluarse antes que "todos los días": "todos los días 1"
    # significa el día 1 de cada mes, no los 365 días del año.
    if day_numbers:
        dates = month_days(year, day_numbers, allowed_months)
        schedule_type = "Month Days"
        relationship = relationship_from_text(text)
        calendar_rule = "D" + ",D".join(str(value) for value in sorted(day_numbers))
        regular_calendar = ""
        based_on_mode = ""
        explanation = "Se seleccionan los días de mes indicados y se aplican los meses solicitados."
        warnings: list[str] = []

        if selected_weekdays:
            weekday_dates = weekdays(year, selected_weekdays, allowed_months)
            dates = dates | weekday_dates if relationship == "OR" else dates & weekday_dates
            schedule_type = "Advanced Scheduling"
            calendar_rule += f" {relationship} Week Days"
            explanation = f"Se combinan días del mes y días de semana mediante {relationship}."
        elif excluded_weekdays:
            dates = {value for value in dates if value.weekday() not in excluded_weekdays}
            schedule_type = "Based on Calendar"
            regular_calendar = "WEEKDAYS" if excluded_weekdays == {5, 6} else ""
            based_on_mode = "Month Days (Dependent on Calendar)" if regular_calendar else ""
            calendar_rule += " con exclusión de días de semana"
            explanation = "Se seleccionan los días del mes y se eliminan los días de semana excluidos."

        if mentioned:
            definition = catalog.definition(mentioned[0])
            if definition:
                calendar_dates, definition_warnings = dates_for_definition(definition, year)
                calendar_dates = {value for value in calendar_dates if value.month in allowed_months}
                if calendar_is_excluded:
                    dates -= calendar_dates
                    explanation += f" Se excluyen las fechas de {mentioned[0]}."
                else:
                    dates &= calendar_dates
                    regular_calendar = mentioned[0]
                    based_on_mode = "Month Days (Dependent on Calendar)"
                    schedule_type = "Based on Calendar"
                    explanation += f" Los días deben existir también en {mentioned[0]}."
                warnings.extend(definition_warnings)
            else:
                warnings.append(
                    f"{mentioned[0]} existe en el catálogo, pero no se puede aplicar porque el Excel no contiene su regla interna."
                )

        proposal = ScheduleProposal(
            query=query,
            year=year,
            title=f"Días {', '.join(map(str, sorted(day_numbers)))} en {month_selection.label}",
            schedule_type=schedule_type,
            selected_dates=dates,
            days_of_month=[str(value) for value in sorted(day_numbers)],
            days_of_week=[WEEKDAY_NAMES[index] for index in sorted(selected_weekdays)],
            months=sorted(allowed_months),
            regular_calendar=regular_calendar,
            based_on_mode=based_on_mode,
            calendar_rule=calendar_rule,
            relationship=relationship,
            confidence="Alta",
            explanation=explanation,
            warnings=warnings,
            assumptions=list(month_selection.assumptions),
        )
        return _decorate(proposal, catalog)

    # Calendario laborable o ejecución diaria sin fines de semana/festivos.
    if (
        "LABORABL" in text
        or "SIN FINES DE SEMANA" in text
        or "SIN FIN DE SEMANA" in text
        or "LUNES A VIERNES" in text
        or "DIAS LABORABLES" in text
        or "ENTRE SEMANA" in text
    ):
        holidays = _national_holidays(year)
        use_holidays = "FESTIV" in text or "LABORABL" in text
        dates = business_days(year, holidays if use_holidays else set())
        dates = {value for value in dates if value.month in allowed_months}
        proposal = ScheduleProposal(
            query=query, year=year,
            title="Días laborables" if use_holidays else "Lunes a viernes",
            schedule_type="Based on Calendar" if use_holidays else "Week Days",
            selected_dates=dates,
            days_of_week=WEEKDAY_NAMES[:5],
            regular_calendar="LABORABL" if use_holidays else "",
            based_on_mode="Calendar Days" if use_holidays else "",
            calendar_rule="Order only on calendar days" if use_holidays else "",
            confidence="Alta" if year == 2026 or not use_holidays else "Media",
            explanation="Ejecución de lunes a viernes" + (" excluyendo las fechas de FESTIVOSNAC." if use_holidays else "."),
            months=sorted(allowed_months),
            assumptions=list(month_selection.assumptions),
        )
        if use_holidays and year != 2026:
            proposal.warnings.append("Los festivos exactos solo están cargados para 2026.")
        return _decorate(proposal, catalog)

    # Uno o varios ordinales de días de semana: primer y tercer lunes, último viernes, etc.
    if selected_weekdays and ordinals:
        dates: set[date] = set()
        tokens: list[str] = []
        for selected_day in sorted(selected_weekdays):
            for ordinal in sorted(ordinals):
                dates |= nth_weekday_of_month(year, selected_day, ordinal)
                tokens.append(f"{WEEKDAY_NAMES[selected_day]}:{'L' if ordinal < 0 else 'D'}{abs(ordinal)}W")
        dates = {value for value in dates if value.month in allowed_months}
        ordinal_labels = {
            1: "primer", 2: "segundo", 3: "tercer", 4: "cuarto", 5: "quinto",
            -1: "último", -2: "penúltimo",
        }
        title = (
            ", ".join(ordinal_labels[value] for value in sorted(ordinals))
            + " "
            + ", ".join(WEEKDAY_NAMES[value].lower() for value in sorted(selected_weekdays))
        )
        assumptions = list(month_selection.assumptions)
        if len(selected_weekdays) > 1 and len(ordinals) > 1:
            assumptions.append("Se aplica cada ordinal indicado a cada día de semana indicado.")
        proposal = ScheduleProposal(
            query=query, year=year, title=title, schedule_type="Advanced Scheduling",
            selected_dates=dates,
            days_of_week=[WEEKDAY_NAMES[value] for value in sorted(selected_weekdays)],
            months=sorted(allowed_months),
            calendar_rule=" + ".join(tokens), confidence="Alta",
            explanation="Se selecciona el día de la semana dentro de la semana ordinal del mes.",
            assumptions=assumptions,
        )
        return _decorate(proposal, catalog)

    # Dos domingos al mes cada dos semanas: primera y tercera semana.
    if "DOMING" in text and ("CADA DOS SEMANAS" in text or "CADA 2 SEMANAS" in text or "DOS DOMINGOS" in text):
        dates = nth_weekday_of_month(year, 6, 1) | nth_weekday_of_month(year, 6, 3)
        dates = {value for value in dates if value.month in allowed_months}
        proposal = ScheduleProposal(
            query=query, year=year, title="Primer y tercer domingo de cada mes",
            schedule_type="Advanced Scheduling", selected_dates=dates,
            days_of_week=["Domingo"], calendar_rule="W1/Domingo + W3/Domingo",
            confidence="Media",
            explanation="Se interpreta como dos domingos separados por dos semanas.",
            months=sorted(allowed_months),
            assumptions=[
                "Se usan el primer y el tercer domingo de cada mes; confirme el anclaje deseado.",
                *month_selection.assumptions,
            ],
        )
        return _decorate(proposal, catalog)

    # Penúltimo/último día natural del mes, opcionalmente evitando fin de semana.
    if "PENULTIMO" in text or "ULTIMO DIA" in text:
        avoid_weekend = "SABADO" in text or "DOMINGO" in text or "FIN DE SEMANA" in text
        ordinal = 2 if "PENULTIMO" in text else 1
        if avoid_weekend:
            dates = business_day_from_month_end(year, ordinal)
            schedule_type = "Based on Calendar"
            regular = "WEEKDAYS"
            based_on = "Month Days (Dependent on Calendar)"
        else:
            dates = set()
            for month in range(1, 13):
                import calendar
                last = calendar.monthrange(year, month)[1]
                dates.add(date(year, month, last - ordinal + 1))
            schedule_type = "Month Days"
            regular = ""
            based_on = ""
        dates = {value for value in dates if value.month in allowed_months}
        proposal = ScheduleProposal(
            query=query, year=year,
            title=("Penúltimo" if ordinal == 2 else "Último") + " día del mes" + (" laborable" if avoid_weekend else ""),
            schedule_type=schedule_type, selected_dates=dates,
            days_of_month=[f"L{ordinal}"], regular_calendar=regular, based_on_mode=based_on,
            calendar_rule=f"L{ordinal}", confidence="Alta",
            explanation="Selección relativa desde el final de cada mes.",
            months=sorted(allowed_months),
            assumptions=list(month_selection.assumptions),
        )
        return _decorate(proposal, catalog)

    # Días de semana incluidos o excluidos, con cualquier filtro mensual.
    if selected_weekdays or excluded_weekdays:
        allowed_weekdays = set(selected_weekdays) if selected_weekdays else set(range(7))
        allowed_weekdays -= excluded_weekdays
        dates = weekdays(year, allowed_weekdays, allowed_months)
        names = [WEEKDAY_NAMES[index] for index in sorted(allowed_weekdays)]
        proposal = ScheduleProposal(
            query=query,
            year=year,
            title="Días de semana: " + ", ".join(name.lower() for name in names),
            schedule_type="Week Days",
            selected_dates=dates,
            days_of_week=names,
            months=sorted(allowed_months),
            calendar_rule="Excluir " + ", ".join(WEEKDAY_NAMES[index] for index in sorted(excluded_weekdays)) if excluded_weekdays else "",
            confidence="Alta" if selected_weekdays else "Media",
            explanation="Planificación directa por días de semana y meses seleccionados.",
            assumptions=list(month_selection.assumptions),
        )
        return _decorate(proposal, catalog)

    if any(term in text for term in ("TODOS LOS DIAS", "CADA DIA", "DIARIA", "DIARIO")):
        dates = {value for value in every_day(year) if value.month in allowed_months}
        without_holidays = bool(re.search(r"\b(?:SIN|EXCEPTO|SALVO)\s+(?:LOS\s+)?FESTIV", text))
        warnings: list[str] = []
        if without_holidays:
            holidays = _national_holidays(year)
            dates -= holidays
            if year != 2026:
                warnings.append("Los festivos nacionales exactos solo están cargados para 2026.")
        proposal = ScheduleProposal(
            query=query,
            year=year,
            title="Todos los días" + (" salvo festivos" if without_holidays else ""),
            schedule_type="Advanced Scheduling" if without_holidays else "Every Day",
            selected_dates=dates,
            months=sorted(allowed_months),
            calendar_rule="Every Day - FESTIVOSNAC" if without_holidays else "",
            confidence="Alta" if year == 2026 or not without_holidays else "Media",
            explanation="Ejecución diaria en los meses seleccionados" + (" excluyendo FESTIVOSNAC." if without_holidays else "."),
            warnings=warnings,
            assumptions=list(month_selection.assumptions),
        )
        return _decorate(proposal, catalog)

    # Sin regla interpretable: se devuelve el catálogo sugerido, nunca fechas inventadas.
    proposal = ScheduleProposal(
        query=query, year=year, title="Revisión manual necesaria", schedule_type="No determinado",
        confidence="Baja", explanation="No se ha identificado una regla suficiente para calcular fechas.",
        warnings=["Seleccione una coincidencia del catálogo o reformule indicando día, frecuencia y calendario base."],
    )
    return _decorate(proposal, catalog)
