from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import asdict
from difflib import SequenceMatcher
from pathlib import Path

from app.models import CalendarMatch, CalendarRecord


STOP_WORDS = {
    "A", "AL", "CADA", "COMO", "CON", "DE", "DEL", "EL", "EN", "LA", "LAS",
    "LO", "LOS", "MES", "MESES", "POR", "QUE", "SEGUN", "TODAS", "TODOS", "UN", "UNA",
}

SEMANTIC_ALIASES = {
    "ANUAL": {"ANNUAL", "YEARLY"},
    "BIWEEKLY": {"BISEMANAL", "QUINCENAL"},
    "DAILY": {"DIARIA", "DIARIO"},
    "DOMINGO": {"DOMINGOS", "SUNDAY"},
    "EVERYDAY": {"ALLDAYS", "DAILY", "DIARIA", "DIARIO"},
    "LABORABLE": {"LABORABL", "LABORABLES", "WEEKDAYS", "WORKDAYS"},
    "LUNES": {"MONDAY"},
    "MENSUAL": {"MONTHLY"},
    "SABADO": {"SABADOS", "SATURDAY"},
    "TRIMESTRAL": {"QUARTERLY"},
    "ULTIMO": {"LAST"},
    "VIERNES": {"FRIDAY"},
}


def _meaningful_tokens(value: str) -> set[str]:
    return {token for token in normalize(value).split() if token not in STOP_WORDS and len(token) > 1}


def _expand_tokens(tokens: set[str], normalized_text: str) -> set[str]:
    expanded = set(tokens)
    if "CADA 2 SEMANAS" in normalized_text or "DOS SEMANAS" in normalized_text:
        expanded.update({"BIWEEKLY", "BISEMANAL", "CADA2DOM"})
    if "CADA 3 MESES" in normalized_text or "TRIMESTRAL" in normalized_text:
        expanded.update({"QUARTERLY", "TRIMESTRAL"})
    if "TODOS LOS DIAS" in normalized_text or "CADA DIA" in normalized_text:
        expanded.update({"ALLDAYS", "EVERYDAY", "DAILY"})
    for token in list(expanded):
        expanded.update(SEMANTIC_ALIASES.get(token, set()))
    return expanded


def normalize(value: str) -> str:
    value = unicodedata.normalize("NFKD", str(value or ""))
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r"[^A-Z0-9]+", " ", value.upper()).strip()


class CalendarCatalog:
    def __init__(self, records: list[CalendarRecord], definitions: dict | None = None):
        self.records = records
        self.definitions = definitions or {}

    @classmethod
    def from_json(cls, catalog_path: Path, definitions_path: Path):
        raw_catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
        raw_definitions = json.loads(definitions_path.read_text(encoding="utf-8"))
        records = [CalendarRecord(**item) for item in raw_catalog.get("records", [])]
        return cls(records, raw_definitions.get("definitions", {}))

    @classmethod
    def from_spreadsheet(cls, path: str | Path, definitions: dict | None = None):
        try:
            import pandas as pd
        except ImportError as exc:
            raise RuntimeError("Para cargar Excel instala las dependencias con: py -m pip install -r requirements.txt") from exc

        path = Path(path)
        if path.suffix.lower() == ".csv":
            frame = pd.read_csv(path)
        else:
            frame = pd.read_excel(path)
        frame.columns = [str(c).strip() for c in frame.columns]
        required = {"Calendar Name", "Control-M Server", "Type"}
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError("Faltan columnas obligatorias: " + ", ".join(sorted(missing)))

        records: list[CalendarRecord] = []
        for _, row in frame.iterrows():
            name = str(row.get("Calendar Name", "")).strip()
            if not name or name.lower() == "nan":
                continue
            last_sync = row.get("Last Synchronized", "")
            if str(last_sync).lower() in {"nat", "nan", "none"}:
                last_sync = ""
            records.append(CalendarRecord(
                name=name,
                server=str(row.get("Control-M Server", "") or "").strip(),
                calendar_type=str(row.get("Type", "") or "").strip(),
                synchronization_state=str(row.get("Synchronization State", "") or "").strip(),
                last_synchronized=str(last_sync),
                source=path.name,
            ))
        return cls(records, definitions or {})

    def to_json(self) -> dict:
        return {"records": [asdict(record) for record in self.records]}

    def definition(self, name: str) -> dict | None:
        normalized = normalize(name).replace(" ", "")
        for key, value in self.definitions.items():
            if normalize(key).replace(" ", "") == normalized:
                return value
        return None

    def find_exact(self, name: str) -> list[CalendarRecord]:
        key = normalize(name).replace(" ", "")
        return [record for record in self.records if normalize(record.name).replace(" ", "") == key]

    def names_mentioned(self, text: str) -> list[str]:
        normalized_text = " " + normalize(text) + " "
        found: list[str] = []
        for record in self.records:
            candidate = normalize(record.name)
            if candidate and f" {candidate} " in normalized_text:
                found.append(record.name)
        return list(dict.fromkeys(found))

    def search(self, text: str, limit: int = 8) -> list[CalendarMatch]:
        query = normalize(text)
        query_tokens = _expand_tokens(_meaningful_tokens(query), query)
        matches: list[CalendarMatch] = []
        for record in self.records:
            name = normalize(record.name)
            compact_name = name.replace(" ", "")
            compact_query = query.replace(" ", "")
            definition = self.definition(record.name)
            description = normalize((definition or {}).get("description", ""))
            name_tokens = _expand_tokens(_meaningful_tokens(name), name)
            description_tokens = _expand_tokens(_meaningful_tokens(description), description)
            score = SequenceMatcher(None, compact_query, compact_name).ratio() * 35
            token_hits = len(query_tokens & (name_tokens | description_tokens))
            score += min(token_hits * 13, 39)
            reason = "Coincidencia aproximada por nombre"
            if compact_name and compact_name in compact_query:
                score += 60
                reason = "Nombre del calendario indicado en la petición"
            if definition:
                score += 12
                if token_hits:
                    reason = "Coincidencia con una regla conocida y su descripción"
            matches.append(CalendarMatch(record, round(score, 1), reason, bool(definition)))
        matches.sort(key=lambda item: (-item.score, item.record.name, item.record.calendar_type))
        return matches[:limit]
