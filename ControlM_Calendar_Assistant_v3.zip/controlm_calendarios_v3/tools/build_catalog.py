"""Convierte el Excel corporativo en el catálogo JSON incluido en la app."""

import argparse
import json
from pathlib import Path

import pandas as pd


def clean(value):
    if pd.isna(value):
        return ""
    return str(value).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    frame = pd.read_excel(args.input)
    records = []
    for _, row in frame.iterrows():
        name = clean(row.get("Calendar Name"))
        if not name:
            continue
        records.append({
            "name": name,
            "server": clean(row.get("Control-M Server")),
            "calendar_type": clean(row.get("Type")),
            "synchronization_state": clean(row.get("Synchronization State")),
            "last_synchronized": clean(row.get("Last Synchronized")),
            "source": args.input.name,
        })
    payload = {
        "source": args.input.name,
        "record_count": len(records),
        "unique_name_count": len({item["name"] for item in records}),
        "records": records,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: payload[key] for key in ("record_count", "unique_name_count")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
