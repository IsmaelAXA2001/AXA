@echo off
setlocal
cd /d "%~dp0"
py main.py
if errorlevel 1 (
  echo.
  echo La aplicacion no ha podido iniciarse.
  echo Ejecuta primero instalar_dependencias.bat.
  pause
)
endlocal
