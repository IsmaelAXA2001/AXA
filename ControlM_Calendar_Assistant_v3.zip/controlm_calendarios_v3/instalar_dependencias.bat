@echo off
setlocal
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo No se han podido instalar las dependencias.
  pause
) else (
  echo.
  echo Dependencias instaladas correctamente.
  pause
)
endlocal
