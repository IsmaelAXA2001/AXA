# -*- coding: utf-8 -*-
"""Punto de entrada de Control-M Calendar Assistant."""

import tkinter as tk

from app.ui import ControlMCalendarApp


def main():
    root = tk.Tk()
    ControlMCalendarApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
