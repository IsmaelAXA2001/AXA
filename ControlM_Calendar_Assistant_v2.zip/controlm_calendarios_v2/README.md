# Control-M Calendar Assistant v2

Aplicación de escritorio para convertir peticiones escritas en lenguaje natural en una propuesta de Scheduling de Control-M, mostrar las fechas en una vista anual y localizar calendarios existentes del catálogo corporativo.

## Inicio rápido

1. Ejecuta `instalar_dependencias.bat` una sola vez.
2. Ejecuta `iniciar_calendarios.bat`.
3. Escribe una petición, por ejemplo `Todos los lunes del mes`.
4. Pulsa `Analizar y mostrar`.

También puede iniciarse desde VS Code:

```text
py -m pip install -r requirements.txt
py main.py
```

## Qué muestra

- Vista anual de 12 meses inspirada en `View Schedule` de Control-M.
- Fechas seleccionadas en naranja.
- Tipo de Schedule recomendado.
- Days of month, Days of week y Order on Months.
- Based on Calendar y Regular Calendar cuando correspondan.
- Coincidencias con los calendarios existentes del Excel.
- Indicación explícita de si hay un calendario reutilizable y si la coincidencia está confirmada o es solo una sugerencia.
- Confianza, supuestos y advertencias de validación.
- Botón para copiar la propuesta al portapapeles.

## Catálogo incluido

El catálogo procede de `Calendarios (1)(1).xls` y contiene 90 registros y 88 nombres únicos. La aplicación conserva registros duplicados cuando el nombre existe con distinto tipo o servidor.

Puede cargarse un catálogo actualizado desde `Cargar Excel`. Debe contener como mínimo estas columnas:

- `Calendar Name`
- `Control-M Server`
- `Type`

## Diferencia entre catálogo y definición

El Excel aportado contiene nombres y metadatos, pero no las fechas ni reglas internas. Por eso la aplicación separa:

- `Regla: Sí`: existe una definición conocida y la vista anual puede calcularse.
- `Regla: No`: es una coincidencia por nombre/tipo/servidor; no se inventan fechas.

Las definiciones conocidas están en `data/calendar_definitions.json`. Puede ampliarse ese archivo con futuros exports.

## Reglas inicialmente cubiertas

- Every Day.
- Días concretos de la semana.
- Lunes a viernes.
- Días laborables según `LABORABL` para 2026.
- Festivos nacionales `FESTIVOSNAC` para 2026.
- `CALCIERR`: último día del mes, salvo domingo.
- Primer, segundo, tercer, cuarto o último día de semana del mes.
- Primer, último y penúltimo día laborable.
- Cada N meses en un día de mes.
- Uno o varios días del mes, por ejemplo 1, 5 y 20.
- Rangos de días, por ejemplo del día 10 al 15.
- Meses pares, impares, concretos, rangos de meses y trimestres.
- Ciclos cada N meses con un mes de inicio opcional.
- Combinaciones de días del mes y de semana mediante AND u OR.
- Inclusión o exclusión de días de semana.
- Varios ordinales, por ejemplo primer y tercer lunes.
- Dos domingos al mes cada dos semanas, con supuesto W1 y W3.
- Desplazamiento de días sobre un calendario conocido, marcado para validación técnica.

## Límites importantes

- La propuesta es una ayuda de diseño; debe validarse en `View Schedule` antes de publicar el job.
- Los festivos exactos solo están cargados para 2026.
- Los calendarios periódicos o Rule-based cuyo contenido no aparece en los archivos se sugieren, pero no se simulan.
- El desplazamiento relativo puede requerir una RBC derivada, una regla relativa o una política de confirmación según el caso real.

## Crear EXE

Ejecuta `crear_exe.bat`. El resultado se genera en `dist\ControlM_Calendarios_v2.exe`.

## Fuentes técnicas

- Captura `View Schedule` aportada.
- `INFO CALENDARIOS.docx`.
- `Calendarios (1)(1).xls`.
- https://documents.bmc.com/supportu/9.0.22/en-US/Documentation/Job_scheduling.htm
- https://documents.bmc.com/supportu/9.0.22/en-US/Documentation/Utilities/defcal.htm
- https://www.boe.es/eli/es/res/2025/10/17/(2)
