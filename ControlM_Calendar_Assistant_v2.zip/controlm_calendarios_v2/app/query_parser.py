from __future__ import annotations

import re
from dataclasses import dataclass, field


MONTH_WORDS = {
    "ENERO": 1,
    "FEBRERO": 2,
    "MARZO": 3,
    "ABRIL": 4,
    "MAYO": 5,
    "JUNIO": 6,
    "JULIO": 7,
    "AGOSTO": 8,
    "SEPTIEMBRE": 9,
    "SETIEMBRE": 9,
    "OCTUBRE": 10,
    "NOVIEMBRE": 11,
    "DICIEMBRE": 12,
}

WEEKDAY_WORDS = {
    "LUNES": 0,
    "MARTES": 1,
    "MIERCOLES": 2,
    "JUEVES": 3,
    "VIERNES": 4,
    "SABADO": 5,
    "SABADOS": 5,
    "DOMINGO": 6,
    "DOMINGOS": 6,
}

ORDINAL_WORDS = {
    "PRIMER": 1,
    "PRIMERO": 1,
    "SEGUNDO": 2,
    "TERCER": 3,
    "TERCERO": 3,
    "CUARTO": 4,
    "QUINTO": 5,
    "ULTIMO": -1,
    "PENULTIMO": -2,
}

EXCLUSION_MARKER = r"(?:EXCEPTO|SALVO|MENOS|SIN|NO\s+SEA|NO\s+SEAN)"


@dataclass
class MonthSelection:
    months: set[int] = field(default_factory=lambda: set(range(1, 13)))
    explicit: bool = False
    label: str = "todos los meses"
    assumptions: list[str] = field(default_factory=list)


def _month_mentions(text: str) -> list[tuple[int, int]]:
    found: list[tuple[int, int]] = []
    for word, number in MONTH_WORDS.items():
        for match in re.finditer(rf"\b{word}\b", text):
            found.append((match.start(), number))
    return sorted(found)


def _inclusive_month_range(start: int, end: int) -> set[int]:
    if start <= end:
        return set(range(start, end + 1))
    return set(range(start, 13)) | set(range(1, end + 1))


def extract_months(text: str) -> MonthSelection:
    selection = MonthSelection()
    constraints: list[set[int]] = []
    labels: list[str] = []

    if re.search(r"\bMESES?\s+PARES\b", text):
        constraints.append({2, 4, 6, 8, 10, 12})
        labels.append("meses pares")
    if re.search(r"\bMESES?\s+IMPARES\b", text):
        constraints.append({1, 3, 5, 7, 9, 11})
        labels.append("meses impares")

    quarter_map = {
        "PRIMER": {1, 2, 3},
        "PRIMERO": {1, 2, 3},
        "SEGUNDO": {4, 5, 6},
        "TERCER": {7, 8, 9},
        "TERCERO": {7, 8, 9},
        "CUARTO": {10, 11, 12},
    }
    for word, months in quarter_map.items():
        if re.search(rf"\b{word}\s+TRIMESTRE\b", text):
            constraints.append(months)
            labels.append(f"{word.lower()} trimestre")
    for quarter in range(1, 5):
        if re.search(rf"\b(?:Q|T){quarter}\b", text):
            months = set(range((quarter - 1) * 3 + 1, quarter * 3 + 1))
            constraints.append(months)
            labels.append(f"trimestre {quarter}")

    range_match = re.search(
        r"\bDE\s+(" + "|".join(MONTH_WORDS) + r")\s+(?:A|HASTA)\s+(" + "|".join(MONTH_WORDS) + r")\b",
        text,
    )
    if range_match:
        start = MONTH_WORDS[range_match.group(1)]
        end = MONTH_WORDS[range_match.group(2)]
        constraints.append(_inclusive_month_range(start, end))
        labels.append(f"de {range_match.group(1).lower()} a {range_match.group(2).lower()}")

    cycle = re.search(r"\bCADA\s+(\d{1,2})\s+MESES?\b", text)
    if cycle:
        step = max(1, min(12, int(cycle.group(1))))
        anchor = 1
        anchor_match = re.search(
            r"\b(?:DESDE|EMPEZANDO\s+EN|A\s+PARTIR\s+DE)\s+(" + "|".join(MONTH_WORDS) + r")\b",
            text,
        )
        if anchor_match:
            anchor = MONTH_WORDS[anchor_match.group(1)]
        else:
            selection.assumptions.append("La secuencia de meses comienza en enero porque no se indicó un mes de inicio.")
        constraints.append(set(range(anchor, 13, step)))
        labels.append(f"cada {step} meses desde {next(name.lower() for name, value in MONTH_WORDS.items() if value == anchor)}")

    exclusion_match = re.search(rf"\b{EXCLUSION_MARKER}\b", text)
    positive_text = text[: exclusion_match.start()] if exclusion_match else text
    excluded_text = text[exclusion_match.end() :] if exclusion_match else ""

    if not cycle and not range_match:
        positive_mentions = {month for _, month in _month_mentions(positive_text)}
        if positive_mentions:
            constraints.append(positive_mentions)
            labels.append("meses indicados")

    excluded_months = {month for _, month in _month_mentions(excluded_text)}
    if re.search(r"\bMESES?\s+PARES\b", excluded_text):
        excluded_months |= {2, 4, 6, 8, 10, 12}
    if re.search(r"\bMESES?\s+IMPARES\b", excluded_text):
        excluded_months |= {1, 3, 5, 7, 9, 11}

    if constraints:
        result = set(range(1, 13))
        for constraint in constraints:
            result &= constraint
        selection.months = result
        selection.explicit = True
        selection.label = " y ".join(dict.fromkeys(labels))
    if excluded_months:
        selection.months -= excluded_months
        selection.explicit = True
        if not labels:
            selection.label = "todos los meses salvo los excluidos"

    return selection


def extract_day_numbers(text: str) -> set[int]:
    values: set[int] = set()

    range_patterns = (
        r"\bDIAS?\s+(?:DEL\s+)?(\d{1,2})\s+(?:AL|HASTA)\s+(?:EL\s+)?(?:DIA\s+)?(\d{1,2})\b",
        r"\bDEL\s+DIA\s+(\d{1,2})\s+(?:AL|HASTA)\s+(?:EL\s+)?DIA\s+(\d{1,2})\b",
    )
    for pattern in range_patterns:
        for match in re.finditer(pattern, text):
            start, end = int(match.group(1)), int(match.group(2))
            if 1 <= start <= 31 and 1 <= end <= 31:
                low, high = sorted((start, end))
                values.update(range(low, high + 1))

    stop_pattern = re.compile(
        r"\b(?:SOLO|UNICAMENTE|EXCEPTO|SALVO|MENOS|DURANTE|EN\s+LOS\s+MESES?|"
        r"MESES?\s+PARES|MESES?\s+IMPARES|CADA\s+\d{1,2}\s+MESES?)\b"
    )
    for marker in re.finditer(r"\bDIAS?\b", text):
        tail = text[marker.end() : marker.end() + 120]
        stop = stop_pattern.search(tail)
        if stop:
            tail = tail[: stop.start()]
        for raw in re.findall(r"\b(\d{1,2})\b", tail):
            number = int(raw)
            if 1 <= number <= 31:
                values.add(number)

    compact_list = re.search(
        r"\b(?:EL|LOS)\s+((?:\d{1,2}\s*(?:,|/|Y|E)\s*)+\d{1,2})\s+DE\s+CADA\s+MES\b",
        text,
    )
    if compact_list:
        values.update(int(raw) for raw in re.findall(r"\d{1,2}", compact_list.group(1)) if 1 <= int(raw) <= 31)

    return values


def _weekday_values(text: str) -> set[int]:
    values = {
        number
        for word, number in WEEKDAY_WORDS.items()
        if re.search(rf"\b{word}\b", text)
    }
    range_match = re.search(
        r"\b(?:DE\s+)?(" + "|".join(WEEKDAY_WORDS) + r")\s+A\s+(" + "|".join(WEEKDAY_WORDS) + r")\b",
        text,
    )
    if range_match:
        start = WEEKDAY_WORDS[range_match.group(1)]
        end = WEEKDAY_WORDS[range_match.group(2)]
        if start <= end:
            values |= set(range(start, end + 1))
        else:
            values |= set(range(start, 7)) | set(range(0, end + 1))
    if "ENTRE SEMANA" in text:
        values |= {0, 1, 2, 3, 4}
    if "FIN DE SEMANA" in text or "FINES DE SEMANA" in text:
        values |= {5, 6}
    return values


def extract_weekday_constraints(text: str) -> tuple[set[int], set[int]]:
    marker = re.search(rf"\b{EXCLUSION_MARKER}\b", text)
    if not marker:
        return _weekday_values(text), set()
    included = _weekday_values(text[: marker.start()])
    excluded = _weekday_values(text[marker.end() :])
    return included, excluded


def extract_ordinals(text: str) -> set[int]:
    return {
        number
        for word, number in ORDINAL_WORDS.items()
        if re.search(rf"\b{word}\b", text)
    }


def relationship_from_text(text: str) -> str:
    if re.search(r"\b(?:O|OR)\b", text):
        return "OR"
    return "AND"

